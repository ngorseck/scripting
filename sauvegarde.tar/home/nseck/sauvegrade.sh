#!/bin/bash

#Faire une sauvegarde

tar -cf sauvegarde.tar /home/nseck

echo "La sauvegrade est complete par " $USER "le 'date'" 
date